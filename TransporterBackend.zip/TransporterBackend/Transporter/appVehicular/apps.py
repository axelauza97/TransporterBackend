from django.apps import AppConfig


class AppvehicularConfig(AppConfig):
    name = 'appVehicular'
